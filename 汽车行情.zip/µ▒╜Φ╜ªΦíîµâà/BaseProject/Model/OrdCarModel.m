
//
//  OrdCarModel.m
//  BaseProject
//
//  Created by mis on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "OrdCarModel.h"

@implementation OrdCarModel

@end
@implementation OrdCarResultModel

+ (NSDictionary *)objectClassInArray{
    return @{@"carlist" : [OrdCarCarlistModel class]};
}

@end


@implementation OrdCarCarlistModel

@end


