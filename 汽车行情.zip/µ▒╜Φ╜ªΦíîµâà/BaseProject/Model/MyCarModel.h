//
//  MyCarModel.h
//  imitationZhiLian
//
//  Created by fantasy on 15/11/12.
//  Copyright © 2015年 fantasy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyCarModel : NSObject

@property (nonatomic,copy)NSString *icon;

@property (nonatomic,copy)NSString *name;

@end
