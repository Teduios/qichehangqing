//
//  AppDelegate.m
//  BaseProject
//
//  Created by jiyingxin on 15/10/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "AppDelegate.h"
#import "AppDelegate+Category.h"
//#import "LatestViewController.h"
//#import "OrdCarNetManager.h"
@interface AppDelegate ()
@end
@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    [self initializeWithApplication:application];

//    [OrdCarNetManager getOrdCarSign:@"adf1a94cfd8ffd873c5bb9ee0cfe3f52" Brandid:13 CompletionHandle:^(id model, NSError *error) {
//        NSLog(@"11");
//    }];
    return YES;
}


@end









