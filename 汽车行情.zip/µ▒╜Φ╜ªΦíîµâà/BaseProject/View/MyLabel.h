//
//  MyLabel.h
//  imitationZhiLian
//
//  Created by fantasy on 15/11/12.
//  Copyright © 2015年 fantasy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyLabel : UILabel

@property (nonatomic,assign) int fromValue;

@end
