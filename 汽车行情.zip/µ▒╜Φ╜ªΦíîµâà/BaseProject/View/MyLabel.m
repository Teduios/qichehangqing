//
//  MyLabel.m
//  imitationZhiLian
//
//  Created by fantasy on 15/11/12.
//  Copyright © 2015年 fantasy. All rights reserved.
//

#import "MyLabel.h"

@implementation MyLabel



@end
